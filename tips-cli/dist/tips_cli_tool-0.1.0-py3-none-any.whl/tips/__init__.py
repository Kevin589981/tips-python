"""
Temporary Notes CLI Tool.
"""
__version__ = "0.1.0"